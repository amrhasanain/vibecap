ASCII_BANNER = r"""[bold bright_magenta]
       _ _                          
__   _(_) |__   ___  ___ __ _ _ __  
\ \ / / | '_ \ / _ \/ __/ _` | '_ \ 
 \ V /| | |_) |  __/ (_| (_| | |_) |
  \_/ |_|_.__/ \___|\___\__,_| .__/ 
                             |_|    
[/bold bright_magenta][bold cyan]       ⚡ Auto Captions Generator v2.0.1 ⚡[/bold cyan]
"""